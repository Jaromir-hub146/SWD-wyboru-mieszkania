from gui_compare import *


def main():
    root = Tk()
    my_gui = App(root)
    root.mainloop()


if __name__ == '__main__':
    main()
